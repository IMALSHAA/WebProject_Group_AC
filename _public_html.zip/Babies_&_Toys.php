<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Babies Items</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-primary px-3">
  <a class="navbar-brand" href="#">Online Shopping Center</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="mx-auto">
      <div class="navbar-nav">
        <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only"></span></a>
        <a class="nav-item nav-link" href="about.php">About</a>
        <a class="nav-item nav-link" href="contact.php">Contact Info</a>
        <div class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Items Category
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="Electronic_Items.php">Electronic Items</a></li>
            <li><a class="dropdown-item" href="Babies_&_Toys.php">Babies & Toys</a></li>
            <li><a class="dropdown-item" href="Fashion_Items.php">Fashion Items</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">View All Items</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="d-flex">
      <a href="seller_loging.php"><button type="button" class="btn btn-success me-2">Login As Seller</button></a>
      <a href="loging.php"><button type="button" class="btn btn-danger">Login As Buyer</button></a>
    </div>
  </div>
</nav>

<div class="container mt-5">
    <h1 class="mb-4">Babies & Toys</h1>
    <div class="row">
        <?php
        include('db_connection.php');
        $sql = "SELECT * FROM Items WHERE Category = 'Babies & Toys'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo '<div class="col-md-4 mb-4">';
                echo '<div class="card">';
                echo '<img src="' . $row["Images"] . '" class="card-img-top" alt="Item Image">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . $row["Item_Name"] . '</h5>';
                echo '<p class="card-text">' . $row["Description"] . '</p>';
                echo '<p class="card-text"><strong>Price: </strong>' . $row["Prize"] . '</p>';
                echo '<p class="card-text"><strong>Quantity: </strong>' . $row["Quantity"] . '</p>';
                echo '<a href="#" class="btn btn-primary">Edit</a>';
                echo '<a href="#" class="btn btn-danger ms-2">Delete</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No electronic items found.</p>';
        }

        $conn->close();
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
