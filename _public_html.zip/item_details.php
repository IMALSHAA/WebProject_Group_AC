<?php
session_start();
include('db_connection.php');
$buyerLoggedIn = isset($_SESSION['Buyer_id']);


if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$itemId = $_GET['id'];

$sql = "SELECT * FROM Items WHERE Item_id = '$itemId'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    header('Location: index.php');
    exit();
}

$item = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $item['Item_Name']; ?> - Item Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .icon-dark i {
            color: #343a40;
        }
        .item-image {
            width: 100%;
            height: auto;
            max-height: 400px;
            object-fit: cover;
        }
        .price {
            font-size: 1.5rem;
            color: #ED0002;
        }
    </style>
</head>
<body>
<?php
include('navbar.php');
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo $item['Images']; ?>" class="item-image" alt="Item Image">
        </div>
        <div class="col-md-6">
            <h1><?php echo $item['Item_Name']; ?></h1>
            <p class="price">$<?php echo $item['Prize']; ?></p>
            <p><?php echo $item['Description']; ?></p>
            <p><strong>Quantity: </strong><?php echo $item['Quantity']; ?></p>
            <form method="POST" action="add_to_cart.php">
                <input type="hidden" name="item_id" value="<?php echo $item['Item_id']; ?>">
                <button type="submit" class="btn btn-primary">Add To Cart</button>
                <button type="button" class="btn btn-danger" onclick="location.href='checkout.php?id=<?php echo $item['Item_id']; ?>'">Buy Now</button>
            </form>
        </div>
    </div>
</div>

<?php
include('footer.php');
?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
