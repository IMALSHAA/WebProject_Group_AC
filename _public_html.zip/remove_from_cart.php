<?php
session_start();
include('db_connection.php');

$buyerLoggedIn = isset($_SESSION['Buyer_id']);
$buyerId = $buyerLoggedIn ? $_SESSION['Buyer_id'] : null;

if (!$buyerLoggedIn) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $itemId = isset($_POST['item_id']) ? $_POST['item_id'] : null;

    if ($itemId) {
        // Delete the item from the cart for the logged-in buyer
        $sql = "DELETE FROM Cart WHERE Buyer_id = ? AND Item_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $buyerId, $itemId);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Item removed from cart']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to remove item from cart']);
        }
        
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid item ID']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

$conn->close();
?>
