<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['Buyer_id'])) {
    header('Location: loging.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['item_id'])) {
    $itemId = $_POST['item_id'];
    $buyerId = $_SESSION['Buyer_id'];

    $sql = "INSERT INTO Cart (Buyer_id, Item_id) VALUES ('$buyerId', '$itemId')";

    if ($conn->query($sql) === TRUE) {
        header('Location: cart.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

