<?php
session_start();
$buyerLoggedIn = isset($_SESSION['Buyer_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<nav class="navbar navbar-expand-lg navbar-light bg-primary px-3">
  <a class="navbar-brand" href="#">Online Shopping Center</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="mx-auto">
      <div class="navbar-nav">
        <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only"></span></a>
        <a class="nav-item nav-link" href="about.php">About</a>
        <a class="nav-item nav-link" href="contact.php">Contact Info</a>
        <div class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Items Category
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="Electronic_Items.php">Electronic Items</a></li>
            <li><a class="dropdown-item" href="Babies_&_Toys.php">Babies & Toys</a></li>
            <li><a class="dropdown-item" href="Fashion_Items.php">Fashion Items</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">View All Items</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="d-flex align-items-center">
      <a href="#" class="icon-dark me-3"><i class="fas fa-bell"></i></a>
      <a href="#" class="icon-dark me-3"><i class="fas fa-shopping-cart"></i></a>
      <?php if (!$buyerLoggedIn && !$sellerLoggedIn): ?>
        <a href="seller_loging.php"><button type="button" class="btn btn-success me-2">Login As Seller</button></a>
        <a href="loging.php"><button type="button" class="btn btn-danger">Login As Buyer</button></a>
      <?php else: ?>
        <a href="logout.php"><button type="button" class="btn btn-warning">Log Out</button></a>
      <?php endif; ?>
    </div>
  </div>
</nav>
<br>
<footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <h5>About Us</h5>
          <p>Online Shopping Center is your one-stop shop for all your needs. From electronics to fashion, we have it all.</p>
        </div>
        <div class="col-md-4">
          <h5>Quick Links</h5>
          <ul class="list-unstyled">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact Info</a></li>
            <li><a href="#">View All Items</a></li>
          </ul>
        </div>
        <div class="col-md-4">
          <h5>Contact Us</h5>
          <ul class="list-unstyled">
            <li><i class="fas fa-map-marker-alt"></i> 123 Shopping St, Shop City</li>
            <li><i class="fas fa-phone"></i> +1 (123) 456-7890</li>
            <li><i class="fas fa-envelope"></i> info@onlineshopping.com</li>
          </ul>
        </div>
      </div>
      <div class="row mt-3">
        <div class="col-md-12 text-center">
          <p>&copy; 2024 Online Shopping Center. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<style>
  .icon-dark i {
    color: #343a40;
  }
</style>
<style>
    .footer {
      background-color: #007bff; /* Same as bg-primary */
      color: white;
      padding: 20px 0;
    }
    .footer a {
      color: white;
    }
    .footer a:hover {
      color: #d4d4d4;
    }
  </style>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
